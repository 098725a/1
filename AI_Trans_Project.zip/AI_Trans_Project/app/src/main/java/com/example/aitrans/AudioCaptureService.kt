package com.example.aitrans

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.io.File

class AudioCaptureService : Service() {
    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AITrans::CaptureWakeLock")
        wakeLock?.acquire(10 * 60 * 1000L)
    }

    @SuppressLint("WrongConstant", "ForegroundServiceType")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = NotificationCompat.Builder(this, "CHANNEL_AUDIO_CAPTURE")
            .setContentTitle("AI 视频音频同传系统已挂载")
            .setContentText("系统总线级 100% 纯内录捕获正在流畅监听音轨...")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .build()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1002, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1002, notification)
        }

        val resultCode = intent?.getIntExtra("RESULT_CODE", 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>("RESULT_DATA")

        if (resultCode != 0 && resultData != null) {
            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mpManager.getMediaProjection(resultCode, resultData)
            startSystemAudioLoop()
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startSystemAudioLoop() {
        val projection = mediaProjection ?: return
        
        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .build()

        val sampleRate = 16000 
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4

        audioRecord = AudioRecord.Builder()
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build())
            .setAudioPlaybackCaptureConfig(captureConfig)
            .setBufferSizeInBytes(bufferSize)
            .build()

        audioRecord?.startRecording()
        isRecording = true

        serviceScope.launch {
            val shortBuffer = ShortArray(bufferSize)
            val pcmChunkList = ArrayList<Float>()

            while (isRecording) {
                val samplesRead = audioRecord?.read(shortBuffer, 0, shortBuffer.size) ?: 0
                if (samplesRead > 0) {
                    for (i in 0 until samplesRead) {
                        pcmChunkList.add(shortBuffer[i] / 32768.0f)
                    }
                }

                if (pcmChunkList.size >= 16000 * 3.5) {
                    val currentSamples = pcmChunkList.toFloatArray()
                    pcmChunkList.clear()

                    val rawJapaneseText = if (WhisperEngine.currentEngineMode.contains("兜底")) {
                        WhisperEngine.transcribeWithBackupEngine(currentSamples)
                    } else {
                        WhisperEngine.fullTranscribe(currentSamples, currentSamples.size)
                    }

                    if (rawJapaneseText.isNotBlank() && rawJapaneseText != "Engine Not Initialized") {
                        val broadcastIntent = Intent("com.example.aitrans.ACTION_TRANSLATE_STREAM").apply {
                            putExtra("RAW_JAPANESE_AUDIO_TEXT", rawJapaneseText)
                        }
                        sendBroadcast(broadcastIntent)
                    }
                }
                delay(50)
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel("CHANNEL_AUDIO_CAPTURE", "AI Audio Service", NotificationManager.IMPORTANCE_HIGH)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        isRecording = false
        audioRecord?.stop()
        audioRecord?.release()
        mediaProjection?.stop()
        wakeLock?.let { if (it.isHeld) it.release() }
        serviceScope.cancel()
        super.onDestroy()
    }
}