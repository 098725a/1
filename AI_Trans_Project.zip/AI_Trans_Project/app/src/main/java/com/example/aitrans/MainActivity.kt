package com.example.aitrans

import android.app.Activity
import android.content.*
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.media.projection.MediaProjectionManager
import android.os.PowerManager
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    private var isDownloading by mutableStateOf(false)
    private var downloadProgress by mutableStateOf(0f)
    private var currentOutputTranslation by mutableStateOf("等待视频音频输入中...")
    
    private val asrOptions = listOf("引擎一（极致准确: Large-v3）", "引擎二（均衡流畅: Medium）", "引擎三（省电兜底: 轻量级）")
    private val llmOptions = listOf("1. DeepSeek API", "2. OpenAI (GPT-4o) API", "3. Claude (Anthropic) API", "4. 纯本地离线翻译小模型（Qwen2-1.5B）")
    
    private var selectedAsr by mutableStateOf(asrOptions[0])
    private var selectedLlm by mutableStateOf(llmOptions[0])
    private var isFullPowerMode by mutableStateOf(true) 

    private val mediaProjectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("RESULT_DATA", result.data)
            }
            startForegroundService(serviceIntent)
            Toast.makeText(this, "🎉 100% 纯内录音轨捕获成功!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "❌ 拒绝内录授权", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkOverlayAndBatteryPermissions()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("AI 视频声音听翻控制台", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

                        Row(modifier = Modifier.fillMaxWidth().background(Color.LightGray.copy(alpha = 0.2f)).padding(10.dp), 
                            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("性能调度：火力全开模式 (红米K80全核开)")
                            Switch(checked = isFullPowerMode, onCheckedChange = { 
                                isFullPowerMode = it 
                                WhisperEngine.threadCount = if (it) 8 else 4
                            })
                        }

                        Text("本地 ASR 引擎级别切换:", fontWeight = FontWeight.Bold)
                        asrOptions.forEach { option ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = (selectedAsr == option), onClick = { 
                                    selectedAsr = option
                                    WhisperEngine.currentEngineMode = option
                                })
                                Text(option)
                            }
                        }

                        Text("无审查文本翻译大模型选择:", fontWeight = FontWeight.Bold)
                        llmOptions.forEach { option ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = (selectedLlm == option), onClick = { selectedLlm = option })
                                Text(option)
                            }
                        }

                        if (isDownloading) {
                            LinearProgressIndicator(progress = { downloadProgress }, modifier = Modifier.fillMaxWidth().height(8.dp))
                            Text("正在下载离线大模型组件: ${(downloadProgress * 100).toInt()}%")
                        } else {
                            Button(onClick = {
                                isDownloading = true
                                MainScope().launch {
                                    val localModelFile = File(getExternalFilesDir(null), "whisper-large-v3.bin")
                                    ModelDownloader.downloadModelWithResume("https://pub-models.com", localModelFile) { progress ->
                                        downloadProgress = progress
                                    }
                                    isDownloading = false
                                    WhisperEngine.initModel(localModelFile.absolutePath, WhisperEngine.threadCount)
                                    Toast.makeText(this@MainActivity, "本地单机引擎加载成功！", Toast.LENGTH_SHORT).show()
                                }
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text("步骤一：点此下载/断点续传离线 AI 模型")
                            }
                        }

                        Button(onClick = {
                            startSystemAudioCapture()
                            showSystemAlertWindow()
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))) {
                            Text("步骤二：唤醒全局内录翻译悬浮窗", color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("实时监控: $currentOutputTranslation", color = Color.Gray)
                    }
                }
            }
        }
    }

    private fun checkOverlayAndBatteryPermissions() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
    }

    private fun startSystemAudioCapture() {
        val mpManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun showSystemAlertWindow() {
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val floatTextView = TextView(this).apply {
            text = "【实时无拦截 AI 字幕常驻中】"
            setTextColor(android.graphics.Color.YELLOW)
            setTextSize(18f)
            setTypeface(android.graphics.Typeface.DEFAULT_BOLD)
            setBackgroundColor(android.graphics.Color.parseColor("#CC000000"))
            setPadding(25, 15, 25, 15)
        }

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            y = 150 
        }

        windowManager.addView(floatTextView, layoutParams)

        registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val rawJpn = intent?.getStringExtra("RAW_JAPANESE_AUDIO_TEXT") ?: ""
                MainScope().launch {
                    val translatedChinese = TranslationManager.translateText(this@MainActivity, rawJpn, selectedLlm)
                    floatTextView.text = translatedChinese
                    currentOutputTranslation = translatedChinese
                }
            }
        }, IntentFilter("com.example.aitrans.ACTION_TRANSLATE_STREAM"), RECEIVER_NOT_EXPORTED)
    }
}