package com.example.aitrans

import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.utils.io.*
import java.io.File
import java.io.RandomAccessFile

object ModelDownloader {
    private val client = HttpClient(CIO)

    suspend fun downloadModelWithResume(url: String, destFile: File, onProgress: (Float) -> Unit) {
        var localDownloadedBytes = if (destFile.exists()) destFile.length() else 0L

        val response = client.get(url) {
            if (localDownloadedBytes > 0) {
                header("Range", "bytes=$localDownloadedBytes-")
            }
        }

        val serverContentLength = response.headers["Content-Length"]?.toLong() ?: 0L
        val totalExpectedBytes = if (response.status.value == 206) {
            serverContentLength + localDownloadedBytes
        } else {
            localDownloadedBytes = 0L 
            serverContentLength
        }

        val channel: ByteReadChannel = response.bodyAsChannel()
        val randomAccessFile = RandomAccessFile(destFile, "rw")
        randomAccessFile.seek(localDownloadedBytes)

        val buffer = ByteArray(16384) 
        try {
            while (!channel.isClosedForRead) {
                val bytesRead = channel.readAvailable(buffer, 0, buffer.size)
                if (bytesRead <= 0) break
                
                randomAccessFile.write(buffer, 0, bytesRead)
                localDownloadedBytes += bytesRead
                
                if (totalExpectedBytes > 0) {
                    onProgress(localDownloadedBytes.toFloat() / totalExpectedBytes.toFloat())
                }
            }
        } finally {
            randomAccessFile.close()
        }
    }
}