package com.example.aitrans

import android.util.Log

object WhisperEngine {
    init {
        try {
            System.loadLibrary("whisper_jni")
        } catch (e: UnsatisfiedLinkError) {
            Log.e("WhisperEngine", "JNI 动态库加载失败: ${e.message}")
        }
    }

    var currentEngineMode: String = "引擎一（极致准确: Large-v3）"
    var threadCount: Int = 8 

    external fun initModel(modelPath: String, threads: Int): Boolean
    external fun fullTranscribe(pcmData: FloatArray, numSamples: Int): String

    fun transcribeWithBackupEngine(pcmData: FloatArray): String {
        Log.d("WhisperEngine", "已切换至省电兜底轻量级本地模型进行离线 ASR 识别")
        return "[本地兜底 ASR]"
    }
}